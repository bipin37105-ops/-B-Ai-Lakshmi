# B-Ai Lakshmi native Android prototype

Package: `com.bipin.bai`  
Version: `2.0`

## What this prototype does
- Native Android screen with Start Listening and Stop.
- Requests microphone permission.
- Starts a visible microphone foreground service after the user taps Start.
- Repeatedly uses Android SpeechRecognizer to look for the spoken word "Lakshmi".
- When recognized, it says "Haan, boliye", listens for one more utterance, and reads it back.

## Important limitations
- This is a proof-of-concept, not a production always-on hotword engine.
- Android's SpeechRecognizer documentation says it is not intended for continuous recognition and may stream audio to remote recognition services. It can use battery/data and may stop or behave differently by device.
- The app does not start listening on boot and does not listen until the user taps Start.
- It does not yet connect Gemini or launch other apps.
- A robust low-power hotword detector generally needs a dedicated on-device wake-word SDK/model and additional testing.

## Build
This is a Gradle Android project. It cannot be converted with an HTML-to-APK converter.

A GitHub Actions workflow is included at `.github/workflows/build.yml`. Put the extracted project files in a GitHub repository and run the `Build B-Ai APK` workflow (Actions tab). Download the `B-Ai-Lakshmi-debug-apk` artifact from the completed run.

The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, compile SDK 35.
