B-Ai Lakshmi Native Android Project - Version 2.2

Features in this prototype:
- Visible foreground microphone service; user must start it from the app.
- Uses Android on-device SpeechRecognizer when the device reports it is available (Android 12+); otherwise asks the system recognizer to prefer offline recognition.
- Hindi wake phrase detection for Lakshmi/लक्ष्मी and a one-utterance command mode.
- Opens YouTube and searches videos, opens WhatsApp share sheet for a message (user chooses recipient and manually sends), opens Google web search, Maps search, Settings, and opens the phone dialer for a spoken phone number.

Important limitations:
- This is NOT a dedicated low-power hotword engine. Android SpeechRecognizer is not designed for reliable continuous wake-word detection. Offline operation depends on the phone's installed speech service and Hindi offline language pack; it is not guaranteed.
- Lock-screen wake activation is not guaranteed; Android/HyperOS background, microphone and lock-screen restrictions apply. Start listening manually and keep the visible notification.
- Calls open ACTION_DIAL; the user reviews and taps Call. This prototype does not search Contacts by spoken name yet.
- WhatsApp message share is prepared, but the user chooses the contact, reviews and sends.
- No Gemini API is connected.

Build: GitHub Actions workflow in .github/workflows/build.yml builds a debug APK.
