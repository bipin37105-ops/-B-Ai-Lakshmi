package com.bipin.bai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private static final int REQ = 41;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(36, 60, 36, 36);
        page.setBackgroundColor(0xFF081226);

        TextView title = new TextView(this);
        title.setText("B-Ai  |  LAKSHMI");
        title.setTextColor(0xFF9CCBFF);
        title.setTextSize(28);
        page.addView(title);

        TextView info = new TextView(this);
        info.setText("\nWake phrase: LAKSHMI\n\nTap Start to let the phone listen while this foreground service is active. A persistent Android notification will be shown.\n");
        info.setTextColor(0xFFEAF1FF);
        info.setTextSize(16);
        page.addView(info);

        status = new TextView(this);
        status.setText("Status: stopped");
        status.setTextColor(0xFF8EE7D0);
        status.setTextSize(16);
        page.addView(status);

        Button start = new Button(this);
        start.setText("START LISTENING");
        page.addView(start);
        Button stop = new Button(this);
        stop.setText("STOP");
        page.addView(stop);

        TextView note = new TextView(this);
        note.setText("\nPrototype note: this uses Android speech recognition, not a dedicated offline hotword engine. It may pause, need internet, or vary by phone. It does not secretly listen; press Start and use Stop when finished.");
        note.setTextColor(0xFFFFD58A);
        note.setTextSize(13);
        page.addView(note);

        setContentView(page);

        start.setOnClickListener(v -> requestAndStart());
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, WakeWordService.class));
            status.setText("Status: stopped");
        });
    }

    private void requestAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ);
            return;
        }
        startWakeService();
    }

    private void startWakeService() {
        Intent i = new Intent(this, WakeWordService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Status: listening for “Lakshmi” (notification visible)");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startWakeService();
        else status.setText("Microphone permission was not granted.");
    }
}
