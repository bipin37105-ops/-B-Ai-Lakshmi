package com.bipin.bai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import java.util.Locale;

public class WakeWordService extends Service implements RecognitionListener {
    private static final String CHANNEL = "lakshmi_listening";
    private SpeechRecognizer recognizer;
    private Intent speechIntent;
    private TextToSpeech tts;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private boolean commandMode = false;
    private boolean speaking = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL)
            : new Notification.Builder(this);
        nb.setContentTitle("B-Ai is listening")
          .setContentText("Listening for “Lakshmi”. On-device Hindi recognition is used when available.")
          .setSmallIcon(android.R.drawable.ic_btn_speak_now)
          .setOngoing(true);
        startForeground(7, nb.build());

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            // Prefer Android's on-device recognizer when the device has one.
            // If unavailable, use the system recognizer with an offline preference;
            // the system may still require/download an offline language pack.
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            recognizer.setRecognitionListener(this);
            speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        running = true;
        listenAgain(700);
        return START_NOT_STICKY;
    }

    private void listenAgain(long delay) {
        handler.postDelayed(() -> {
            if (!running || recognizer == null || speaking) return;
            try { recognizer.startListening(speechIntent); }
            catch (Exception e) { listenAgain(1800); }
        }, delay);
    }

    @Override public void onReadyForSpeech(android.os.Bundle params) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float rmsdB) {}
    @Override public void onBufferReceived(byte[] buffer) {}
    @Override public void onEndOfSpeech() {}

    @Override public void onError(int error) {
        if (running) listenAgain(1200);
    }

    @Override public void onResults(android.os.Bundle results) {
        if (!running) return;
        ArrayList<String> words = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String heard = words != null && !words.isEmpty() ? words.get(0).toLowerCase(Locale.ROOT) : "";
        if (!commandMode && (heard.contains("lakshmi") || heard.contains("लक्ष्मी"))) {
            commandMode = true;
            speak("हाँ, बोलिए");
        } else if (commandMode && !heard.isEmpty()) {
            commandMode = false;
            handleCommand(heard);
        } else {
            listenAgain(400);
        }
    }


    private void handleCommand(String command) {
        String c = command.toLowerCase(new Locale("hi", "IN")).trim();
        try {
            if (c.contains("यूट्यूब") || c.contains("youtube")) {
                String query = cleanQuery(c, new String[]{"यूट्यूब", "youtube", "खोलो", "खोल", "पर", "सर्च करो", "सर्च", "चलाओ", "चलाओ", "गाना", "वीडियो"});
                if (query.isEmpty()) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
                    if (launch == null) launch = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"));
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    speak("YouTube खोल रही हूँ");
                } else {
                    Intent search = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
                    search.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(search);
                    speak("YouTube पर खोज रही हूँ: " + query);
                }
            } else if (c.contains("व्हाट्सएप") || c.contains("whatsapp")) {
                if (c.contains("मैसेज") || c.contains("message") || c.contains("भेजो") || c.contains("bhejo")) {
                    String message = extractMessage(c);
                    if (message.isEmpty()) message = "B-Ai से भेजा गया संदेश";
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, message);
                    share.setPackage("com.whatsapp");
                    share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(share);
                    speak("WhatsApp खुल रहा है। संपर्क चुनकर संदेश जाँचें और खुद Send दबाएँ।");
                } else {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
                    if (launch == null) launch = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.whatsapp.com"));
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    speak("WhatsApp खोल रही हूँ");
                }
            } else if (c.contains("कॉल") || c.contains("call") || c.contains("डायल")) {
                String number = c.replaceAll("[^0-9+]", "");
                if (number.length() >= 5) {
                    Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                    dial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(dial);
                    speak("कॉल करने से पहले नंबर जाँच लें");
                } else {
                    speak("अभी नंबर बोलकर कहें, जैसे कॉल करो 98XXXXXXXX");
                }
            } else if (c.contains("मैप") || c.contains("maps") || c.contains("रास्ता") || c.contains("दिशा")) {
                String query = cleanQuery(c, new String[]{"गूगल मैप", "google maps", "मैप", "maps", "खोलो", "खोल", "रास्ता", "दिखाओ", "दिशा", "बताओ"});
                Uri mapUri = query.isEmpty() ? Uri.parse("geo:0,0?q=") : Uri.parse("geo:0,0?q=" + Uri.encode(query));
                Intent map = new Intent(Intent.ACTION_VIEW, mapUri);
                map.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(map);
                speak(query.isEmpty() ? "Maps खोल रही हूँ" : query + " के लिए Maps खोल रही हूँ");
            } else if (c.contains("सेटिंग") || c.contains("settings")) {
                Intent settings = new Intent(android.provider.Settings.ACTION_SETTINGS);
                settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(settings);
                speak("Settings खोल रही हूँ");
            } else if (c.contains("क्रोम") || c.contains("chrome") || c.contains("सर्च") || c.contains("search")) {
                String query = cleanQuery(c, new String[]{"क्रोम", "chrome", "खोलो", "खोल", "सर्च करो", "सर्च", "search", "करो", "पर"});
                if (query.isEmpty()) query = "Google";
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)));
                web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(web);
                speak("खोज रही हूँ: " + query);
            } else {
                speak("अभी यह कमांड उपलब्ध नहीं है। YouTube, WhatsApp, Maps, Settings, वेब सर्च या नंबर से कॉल आज़माएँ।");
            }
        } catch (Exception e) {
            speak("यह ऐप नहीं खुल पाया। ऐप इंस्टॉल है या नहीं जाँचें।");
        }
    }

    private String cleanQuery(String input, String[] remove) {
        String q = input;
        for (String word : remove) q = q.replace(word, " ");
        return q.replaceAll("\\s+", " ").trim();
    }

    private String extractMessage(String input) {
        int idx = input.indexOf("कि");
        if (idx >= 0 && idx + 2 < input.length()) return input.substring(idx + 2).trim();
        idx = input.indexOf("message");
        if (idx >= 0 && idx + 7 < input.length()) return input.substring(idx + 7).trim();
        idx = input.indexOf("मैसेज");
        if (idx >= 0 && idx + 6 < input.length()) return input.substring(idx + 6).trim();
        return "";
    }

    private void speak(String text) {
        if (tts == null) { listenAgain(400); return; }
        speaking = true;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lakshmi_reply");
        handler.postDelayed(() -> {
            speaking = false;
            if (running) listenAgain(500);
        }, 2200);
    }

    @Override public void onPartialResults(android.os.Bundle partialResults) {}
    @Override public void onEvent(int eventType, android.os.Bundle params) {}

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Lakshmi microphone", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Visible notification while Lakshmi wake phrase listening is active");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
