package com.bipin.bai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import java.util.Locale;

public class WakeWordService extends Service implements RecognitionListener {
    private static final String CHANNEL = "lakshmi_listening";
    private SpeechRecognizer recognizer;
    private Intent speechIntent;
    private TextToSpeech tts;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private boolean commandMode = false;
    private boolean speaking = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL)
            : new Notification.Builder(this);
        nb.setContentTitle("B-Ai is listening")
          .setContentText("Say “Lakshmi” to activate. Tap Stop in the app to end.")
          .setSmallIcon(android.R.drawable.ic_btn_speak_now)
          .setOngoing(true);
        startForeground(7, nb.build());

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(this);
            speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        running = true;
        listenAgain(700);
        return START_NOT_STICKY;
    }

    private void listenAgain(long delay) {
        handler.postDelayed(() -> {
            if (!running || recognizer == null || speaking) return;
            try { recognizer.startListening(speechIntent); }
            catch (Exception e) { listenAgain(1800); }
        }, delay);
    }

    @Override public void onReadyForSpeech(android.os.Bundle params) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float rmsdB) {}
    @Override public void onBufferReceived(byte[] buffer) {}
    @Override public void onEndOfSpeech() {}

    @Override public void onError(int error) {
        if (running) listenAgain(1200);
    }

    @Override public void onResults(android.os.Bundle results) {
        if (!running) return;
        ArrayList<String> words = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String heard = words != null && !words.isEmpty() ? words.get(0).toLowerCase(Locale.ROOT) : "";
        if (!commandMode && (heard.contains("lakshmi") || heard.contains("लक्ष्मी"))) {
            commandMode = true;
            speak("हाँ, बोलिए");
        } else if (commandMode && !heard.isEmpty()) {
            speak("आपने कहा: " + heard);
            commandMode = false;
        } else {
            listenAgain(400);
        }
    }

    private void speak(String text) {
        if (tts == null) { listenAgain(400); return; }
        speaking = true;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lakshmi_reply");
        handler.postDelayed(() -> {
            speaking = false;
            if (running) listenAgain(500);
        }, 2200);
    }

    @Override public void onPartialResults(android.os.Bundle partialResults) {}
    @Override public void onEvent(int eventType, android.os.Bundle params) {}

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Lakshmi microphone", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Visible notification while Lakshmi wake phrase listening is active");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
